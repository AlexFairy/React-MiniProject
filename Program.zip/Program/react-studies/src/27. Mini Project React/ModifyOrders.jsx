import React, { useState } from 'react';
import { Button, Form, Alert } from 'react-bootstrap';
import axios from 'axios';

function ModifyOrders() {
  const [orderId, setOrderId] = useState('');
  const [manageOrderHistory, setManageOrderHistory] = useState('');
  const [calTotalPrice, setCalTotalPrice] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleUpdate = async () => {
    try {
      const response = await axios.put(`/ordermanagement/${orderId}`, {
        manage_order_history: manageOrderHistory || undefined,
        cal_total_price: calTotalPrice ? parseFloat(calTotalPrice) : undefined,
      });
      setMessage(response.data.message);
      setError('');
    } catch (err) {
      setError('Error updating order. Please check the details.');
      setMessage('');
    }
  };

  const handleDelete = async () => {
    try {
      const response = await axios.delete(`/ordermanagement/${orderId}`);
      setMessage(response.data.message);
      setError('');
    } catch (err) {
      setError('Error deleting order. Please try again.');
      setMessage('');
    }
  };

  return (
    <div>
      <h3>Modify Orders</h3>
      <Form>
        <Form.Group className="mb-3">
          <Form.Label>Order ID</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Enter order ID" 
            value={orderId} 
            onChange={(e) => setOrderId(e.target.value)} 
            required 
          />
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Order History</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Enter new order history details (optional)" 
            value={manageOrderHistory} 
            onChange={(e) => setManageOrderHistory(e.target.value)} 
          />
        </Form.Group>

        <Form.Group className="mb-3">
          <Form.Label>Total Price</Form.Label>
          <Form.Control 
            type="number" 
            placeholder="Enter new total price (optional)" 
            value={calTotalPrice} 
            onChange={(e) => setCalTotalPrice(e.target.value)} 
          />
        </Form.Group>

        <div className="button-group">
          <Button 
            variant="primary" 
            onClick={handleUpdate} 
            className="me-2"
          >
            Update Order
          </Button>
          <Button 
            variant="danger" 
            onClick={handleDelete}
          >
            Delete Order
          </Button>
        </div>
      </Form>


      {message && <Alert variant="success" className="mt-3">{message}</Alert>}
      {error && <Alert variant="danger" className="mt-3">{error}</Alert>}
    </div>
  );
}

export default ModifyOrders;