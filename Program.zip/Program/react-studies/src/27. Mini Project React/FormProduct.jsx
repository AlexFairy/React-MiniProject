import React, { useState } from 'react';
import { Button, Form, Alert } from 'react-bootstrap';
import axios from 'axios';

function ProductForm() {
  const [productName, setProductName] = useState('');
  const [price, setPrice] = useState('');
  const [stockLevel, setStockLevel] = useState('');
  const [restockItems, setRestockItems] = useState('');
  const [customerId, setCustomerId] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/productcatalog', {
        product_name: productName,
        price: parseFloat(price),
        stock_level: parseInt(stockLevel),
        restock_items: parseInt(restockItems),
        customer_id: parseInt(customerId),
      });
      setMessage(response.data.message);
      setError('');
    } catch (err) {
      setError('Error adding product. Please check the details.');
      setMessage('');
    }
  };

  return (
    <div>
      <h3>Add Product</h3>
      <Form onSubmit={handleSubmit}>
        <Form.Group className="mb-3">
          <Form.Label>Product Name</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Enter product name" 
            value={productName} 
            onChange={(e) => setProductName(e.target.value)} 
            required 
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Price</Form.Label>
          <Form.Control 
            type="number" 
            placeholder="Enter product price" 
            value={price} 
            onChange={(e) => setPrice(e.target.value)} 
            required 
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Stock Level</Form.Label>
          <Form.Control 
            type="number" 
            placeholder="Enter stock level" 
            value={stockLevel} 
            onChange={(e) => setStockLevel(e.target.value)} 
            required 
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Restock Level</Form.Label>
          <Form.Control 
            type="number" 
            placeholder="Enter restock level" 
            value={restockItems} 
            onChange={(e) => setRestockItems(e.target.value)} 
            required 
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Customer ID</Form.Label>
          <Form.Control 
            type="number" 
            placeholder="Enter associated customer ID" 
            value={customerId} 
            onChange={(e) => setCustomerId(e.target.value)} 
            required 
          />
        </Form.Group>
        <Button variant="primary" type="submit">Add Product</Button>
      </Form>
      {message && <Alert variant="success" className="mt-3">{message}</Alert>}
      {error && <Alert variant="danger" className="mt-3">{error}</Alert>}
    </div>
  );
}

export default ProductForm;