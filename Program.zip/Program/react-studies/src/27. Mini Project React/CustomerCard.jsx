import React, { useState } from "react";
import { Container, Row, Col, Card, Button } from "react-bootstrap";
import customer_image1 from './Images/customer1.png';
import customer_image2 from './Images/customer2.png';
import customer_image3 from './Images/customer3.png';
import AccountForm from "./FormAccounts";
import SearchCustomer from "./SearchCustomer";
import ModifyAccounts from "./ModifyAccounts";

const CustomerCard = () => {
  const [showForm, setShowForm] = useState(false);
  const [showSearchCustomer, setShowSearchCustomer] = useState(false);
  const [showModifyAccounts, setShowModifyAccounts] = useState(false);

  const cardData = [
    { 
      title: "Account Form", 
      text: <div style={{ textAlign: 'center' }}>Register <strong>TODAY!</strong></div>, 
      image: customer_image1, 
      buttonText: "Access Forms"
    },
    { 
      title: "Search Customers", 
      text: <div style={{ textAlign: 'center' }}><em>Retrieve</em> Data!</div>, 
      image: customer_image2, 
      buttonText: "Search Database"
    },
    { 
      title: "Modify Accounts", 
      text: <div style={{ textAlign: 'center' }}><u>Modify</u> Account(<strong>s</strong>)</div>, 
      image: customer_image3, 
      buttonText: "Modify Database"
    },
  ];

  return (
    <>
      <h1 className="header-class">Customer Account Menu</h1>
      <Container className="mt-4">
        <Row>
          {cardData.map((card, index) => (
            <Col key={index} xs={12} sm={6} md={4} className="mb-4">
              <Card>
                <Card.Img className="img-two" variant="top" src={card.image} alt={`Card ${index + 1}`} />
                <Card.Body className="card-body">
                  <Card.Title className="card-center">{card.title}</Card.Title>
                  <Card.Text>{card.text}</Card.Text>

                  {index === 0 && (
                    <>
                      <Button 
                        className="card-button" 
                        variant="primary" 
                        onClick={() => setShowForm(!showForm)}
                      >
                        {showForm ? "Hide Form" : card.buttonText}
                      </Button>
                      {showForm && <AccountForm />}
                    </>
                  )}

                  {index === 1 && (
                    <>
                      <Button 
                        className="card-button" 
                        variant="primary" 
                        onClick={() => setShowSearchCustomer(!showSearchCustomer)}
                      >
                        {showSearchCustomer ? "Hide Search" : card.buttonText}
                      </Button>
                      {showSearchCustomer && <SearchCustomer />}
                    </>
                  )}

                  {index === 2 && (
                    <>
                      <Button 
                        className="card-button" 
                        variant="primary" 
                        onClick={() => setShowModifyAccounts(!showModifyAccounts)}
                      >
                        {showModifyAccounts ? "Hide Modify" : card.buttonText}
                      </Button>
                      {showModifyAccounts && <ModifyAccounts />}
                    </>
                  )}
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
    </>
  );
};

export default CustomerCard;