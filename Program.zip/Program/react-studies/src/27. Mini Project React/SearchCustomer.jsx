import React, { useState } from 'react';
import { Form, Button, Alert, ListGroup } from 'react-bootstrap';
import axios from 'axios';

const SearchCustomer = () => {
    const [customerId, setCustomerId] = useState('');
    const [customerData, setCustomerData] = useState(null);
    const [allCustomers, setAllCustomers] = useState([]);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const fetchCustomerById = async () => {
        if (!customerId) {
            setError('Customer ID cannot be empty.');
            return;
        }
        setLoading(true);
        try {
            const response = await axios.get(`/customeraccount/${customerId}`);
            setCustomerData(response.data);
            setError('');
        } catch (err) {
            setError('Customer not found or an error occurred.');
            setCustomerData(null);
        } finally {
            setLoading(false);
        }
    };

    const fetchAllCustomers = async () => {
        setLoading(true);
        try {
            const response = await axios.get('/customeraccount/all');
            setAllCustomers(response.data);
            setError('');
        } catch (err) {
            setError('Error fetching customers.');
            setAllCustomers([]);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{ padding: '20px' }}>
            <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Search Customer</h2>
            <Form>
                <Form.Group className="mb-3">
                    <Form.Label>Search by Customer ID:</Form.Label>
                    <Form.Control
                        type="text"
                        placeholder="Enter Customer ID"
                        value={customerId}
                        onChange={(e) => setCustomerId(e.target.value)}
                    />
                </Form.Group>
                <Button variant="primary" onClick={fetchCustomerById}>
                    {loading ? 'Searching...' : 'Search'}
                </Button>
                {' '}
                <Button variant="secondary" onClick={fetchAllCustomers}>
                    {loading ? 'Loading...' : 'View All Customers'}
                </Button>
            </Form>

            {error && <Alert variant="danger" className="mt-3">{error}</Alert>}

            {customerData && (
                <div className="mt-4">
                    <h3>Customer Details:</h3>
                    <ListGroup>
                        <ListGroup.Item><strong>ID:</strong> {customerData.customer_id}</ListGroup.Item>
                        <ListGroup.Item><strong>Name:</strong> {customerData.name}</ListGroup.Item>
                        <ListGroup.Item><strong>Email:</strong> {customerData.email}</ListGroup.Item>
                        <ListGroup.Item><strong>Phone Number:</strong> {customerData.phone_number}</ListGroup.Item>
                        <ListGroup.Item><strong>Username:</strong> {customerData.username}</ListGroup.Item>
                    </ListGroup>
                </div>
            )}

            {allCustomers.length > 0 && (
                <div className="mt-4">
                    <h3>All Customers:</h3>
                    <ListGroup>
                        {allCustomers.map((customer) => (
                            <ListGroup.Item key={customer.customer_id}>
                                {customer.name} ({customer.email})
                            </ListGroup.Item>
                        ))}
                    </ListGroup>
                </div>
            )}
        </div>
    );
};

export default SearchCustomer;