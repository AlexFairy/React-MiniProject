import React, { useState } from 'react';
import { Button, Form, Alert } from 'react-bootstrap';
import axios from 'axios';

function ModifyProducts() {
  const [productId, setProductId] = useState('');
  const [productName, setProductName] = useState('');
  const [price, setPrice] = useState('');
  const [stockLevel, setStockLevel] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleUpdate = async () => {
    try {
      const response = await axios.put(`/productcatalog/${productId}`, {
        product_name: productName || undefined,
        price: price ? parseFloat(price) : undefined,
        stock_level: stockLevel ? parseInt(stockLevel) : undefined,
      });
      setMessage(response.data.message);
      setError('');
    } catch (err) {
      setError('Error updating product. Please check the details.');
      setMessage('');
    }
  };

  const handleDelete = async () => {
    try {
      const response = await axios.delete(`/productcatalog/${productId}`);
      setMessage(response.data.message);
      setError('');
    } catch (err) {
      setError('Error deleting product. Please try again.');
      setMessage('');
    }
  };

  return (
    <div>
      <h3>Modify Product</h3>
      <Form>
        <Form.Group className="mb-3">
          <Form.Label>Product ID</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Enter product ID" 
            value={productId} 
            onChange={(e) => setProductId(e.target.value)} 
            required 
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Product Name</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Enter new name (optional)" 
            value={productName} 
            onChange={(e) => setProductName(e.target.value)} 
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Price</Form.Label>
          <Form.Control 
            type="number" 
            placeholder="Enter new price (optional)" 
            value={price} 
            onChange={(e) => setPrice(e.target.value)} 
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Stock Level</Form.Label>
          <Form.Control 
            type="number" 
            placeholder="Enter new stock level (optional)" 
            value={stockLevel} 
            onChange={(e) => setStockLevel(e.target.value)} 
          />
        </Form.Group>
        <div className="button-group">
          <Button 
            variant="primary" 
            onClick={handleUpdate} 
            className="me-2"
          >
            Update Product
          </Button>
          <Button 
            variant="danger" 
            onClick={handleDelete}
          >
            Delete Product
          </Button>
        </div>
      </Form>

      {message && <Alert variant="success" className="mt-3">{message}</Alert>}
      {error && <Alert variant="danger" className="mt-3">{error}</Alert>}
    </div>
  );
}

export default ModifyProducts;