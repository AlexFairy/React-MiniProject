import React from 'react';
import { Container, Button, Form } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

function ContactUs() {
  const navigate = useNavigate();

  return (
    <div className="contact-us-page">
      <Container
        fluid
        className="text-center d-flex flex-column justify-content-center align-items-center"
        style={{
          height: '100vh',
          background: 'linear-gradient(to right, #4facfe, #00f2fe)',
          color: '#ffffff',
          padding: '20px',
          position: 'relative',
        }}
      >
        <Button
          variant="light"
          style={{
            position: 'absolute',
            top: '20px',
            left: '20px',
            fontSize: '1rem',
            fontWeight: '600',
            padding: '5px 15px',
            borderRadius: '25px',
          }}
          onClick={() => navigate('/home')}
        >
          Go to Home
        </Button>

        <h1 style={{ fontSize: '3rem', fontWeight: '700', marginBottom: '1rem' }}>
          Contact Us
        </h1>
        <p style={{ fontSize: '1.5rem', fontWeight: '300', marginBottom: '2rem' }}>
          We're here to help. Reach out to us anytime!
        </p>
        <Form style={{ maxWidth: '500px', width: '100%' }}>
          <Form.Group className="mb-3" controlId="contactName">
            <Form.Label style={{ fontSize: '1.2rem' }}>Your Name</Form.Label>
            <Form.Control type="text" placeholder="Enter your name" required />
          </Form.Group>
          <Form.Group className="mb-3" controlId="contactEmail">
            <Form.Label style={{ fontSize: '1.2rem' }}>Your Email</Form.Label>
            <Form.Control type="email" placeholder="Enter your email" required />
          </Form.Group>
          <Form.Group className="mb-3" controlId="contactMessage">
            <Form.Label style={{ fontSize: '1.2rem' }}>Message</Form.Label>
            <Form.Control
              as="textarea"
              rows={4}
              placeholder="Write your message here"
              required
            />
          </Form.Group>
          <Button
            type="submit"
            variant="light"
            style={{
              fontSize: '1.2rem',
              fontWeight: '600',
              padding: '10px 30px',
              borderRadius: '25px',
              boxShadow: '0px 8px 15px rgba(0, 0, 0, 0.1)',
            }}
          >
            Send Message
          </Button>
        </Form>
      </Container>
    </div>
  );
}

export default ContactUs;