import React, { useState } from "react";
import { Container, Row, Col, Card, Button } from "react-bootstrap";
import product_image1 from './Images/product1.png';
import product_image2 from './Images/product2.png';
import product_image3 from './Images/product3.png';
import FormProduct from "./FormProduct";
import SearchProducts from "./SearchProducts";
import ModifyProducts from "./ModifyProducts";

const ProductCard = () => {
  const [showFormProduct, setShowFormProduct] = useState(false);
  const [showSearchProducts, setShowSearchProducts] = useState(false);
  const [showModifyProducts, setShowModifyProducts] = useState(false);

  const productData = [
    { 
      title: "Product Form", 
      text: <div style={{ textAlign: 'center' }}>Register Product(s)</div>, 
      image: product_image1, 
      buttonText: <div style={{ fontWeight: 'bold' }}>Access Forms</div>
    },
    { 
      title: "Search Products", 
      text: <div style={{ textAlign: 'center' }}>Find the Product You Need</div>, 
      image: product_image2, 
      buttonText: <div style={{ fontWeight: 'bold' }}>Search Database</div>
    },
    { 
      title: "Modify Catalog", 
      text: <div style={{ textAlign: 'center' }}>Modify Product Stock</div>, 
      image: product_image3, 
      buttonText: <div style={{ fontWeight: 'bold' }}>Modify Database</div>
    },
  ];

  return (
    <>
      <h1 className="header-class">Product Catalog</h1>
      <Container className="mt-4">
        <Row>
          {productData.map((card, index) => (
            <Col key={index} xs={12} sm={6} md={4} className="mb-4">
              <Card>
                <Card.Img className="img-two" variant="top" src={card.image} alt={`Card ${index + 1}`} />
                <Card.Body className="card-body">
                  <Card.Title className="card-center">{card.title}</Card.Title>
                  <Card.Text>{card.text}</Card.Text>

                  {index === 0 && (
                    <>
                      <Button 
                        className="card-button" 
                        variant="primary" 
                        onClick={() => setShowFormProduct(!showFormProduct)}
                      >
                        {showFormProduct ? "Hide Form" : "Access Forms"}
                      </Button>
                      {showFormProduct && <FormProduct />}
                    </>
                  )}

                  {index === 1 && (
                    <>
                      <Button 
                        className="card-button" 
                        variant="primary" 
                        onClick={() => setShowSearchProducts(!showSearchProducts)}
                      >
                        {showSearchProducts ? "Hide Search" : "Search Database"}
                      </Button>
                      {showSearchProducts && <SearchProducts />}
                    </>
                  )}

                  {index === 2 && (
                    <>
                      <Button 
                        className="card-button" 
                        variant="primary" 
                        onClick={() => setShowModifyProducts(!showModifyProducts)}
                      >
                        {showModifyProducts ? "Hide Modify" : "Modify Database"}
                      </Button>
                      {showModifyProducts && <ModifyProducts />}
                    </>
                  )}
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
    </>
  );
};

export default ProductCard;