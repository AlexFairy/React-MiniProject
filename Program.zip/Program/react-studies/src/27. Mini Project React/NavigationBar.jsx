import React from 'react';
import { NavLink } from 'react-router-dom';
import './react.css';

function NavigationBar() {
  return (
    <nav>
      <NavLink to="/" activeclassname="active">
        Arrive
      </NavLink>
      <NavLink to="/home" activeclassname="active">
        Search
      </NavLink>
      <NavLink to="/contact" activeclassname="active">
        Contact Us
      </NavLink>
    </nav>
  );
}

export default NavigationBar;
