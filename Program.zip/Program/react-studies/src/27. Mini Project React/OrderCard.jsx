import React, { useState } from "react";
import { Container, Row, Col, Card, Button } from "react-bootstrap";
import order_image1 from './Images/order1.png';
import order_image2 from './Images/order2.png';
import order_image3 from './Images/order3.png';
import FormOrder from "./FormOrder";
import SearchOrders from "./SearchOrders";
import ModifyOrders from "./ModifyOrders";

const OrderCard = () => {
  const [showFormOrder, setShowFormOrder] = useState(false);
  const [showSearchOrders, setShowSearchOrders] = useState(false);
  const [showModifyOrders, setShowModifyOrders] = useState(false);

  const orderData = [
    { 
      title: "Order Form", 
      text: <div style={{ textAlign: 'center' }}>Register Order(s)</div>, 
      image: order_image1, 
      buttonText: <div style={{ fontWeight: 'bold' }}>Access Forms</div>
    },
    { 
      title: "Search Order", 
      text: <div style={{ textAlign: 'center' }}>Find <strong>YOUR</strong> Order!</div>, 
      image: order_image2, 
      buttonText: <div style={{ fontWeight: 'bold' }}>Search Database</div>
    },
    { 
      title: "Modify Order", 
      text: <div style={{ textAlign: 'center' }}><em>Manage</em> Orders!</div>, 
      image: order_image3, 
      buttonText: <div style={{ fontWeight: 'bold' }}>Modify Database</div>
    },
  ];

  return (
    <>
      <h1 className="header-class">Order Management</h1>
      <Container className="mt-4">
        <Row>
          {orderData.map((card, index) => (
            <Col key={index} xs={12} sm={6} md={4} className="mb-4">
              <Card>
                <Card.Img className="img-two" variant="top" src={card.image} alt={`Card ${index + 1}`} />
                <Card.Body className="card-body">
                  <Card.Title className="card-center">{card.title}</Card.Title>
                  <Card.Text>{card.text}</Card.Text>

                  {index === 0 && (
                    <>
                      <Button 
                        className="card-button" 
                        variant="primary" 
                        onClick={() => setShowFormOrder(!showFormOrder)}
                      >
                        {showFormOrder ? "Hide Form" : "Access Forms"}
                      </Button>
                      {showFormOrder && <FormOrder />}
                    </>
                  )}

                  {index === 1 && (
                    <>
                      <Button 
                        className="card-button" 
                        variant="primary" 
                        onClick={() => setShowSearchOrders(!showSearchOrders)}
                      >
                        {showSearchOrders ? "Hide Search" : "Search Database"}
                      </Button>
                      {showSearchOrders && <SearchOrders />}
                    </>
                  )}

                  {index === 2 && (
                    <>
                      <Button 
                        className="card-button" 
                        variant="primary" 
                        onClick={() => setShowModifyOrders(!showModifyOrders)}
                      >
                        {showModifyOrders ? "Hide Modify" : "Modify Database"}
                      </Button>
                      {showModifyOrders && <ModifyOrders />}
                    </>
                  )}
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>
    </>
  );
};

export default OrderCard;