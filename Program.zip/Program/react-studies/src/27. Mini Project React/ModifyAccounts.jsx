import React, { useState } from 'react';
import { Button, Form, Alert } from 'react-bootstrap';
import axios from 'axios';

function ModifyAccounts() {
  const [customerId, setCustomerId] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleUpdate = async () => {
    if (!customerId) {
      setError('Customer ID is required for updating.');
      return;
    }
    try {
      const response = await axios.put(`/customeraccount/${customerId}`, {
        name,
        email,
        phone_number: phone,
        username,
        password,
      });
      setMessage(response.data.message);
      setError('');
    } catch (err) {
      setError('Error updating the account. Please check the details.');
      setMessage('');
    }
  };

  const handleDelete = async () => {
    if (!customerId) {
      setError('Customer ID is required for deleting.');
      return;
    }
    try {
      const response = await axios.delete(`/customeraccount/${customerId}`);
      setMessage(response.data.message);
      setError('');
    } catch (err) {
      setError('Error deleting the account. Please try again.');
      setMessage('');
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h2>Modify Customer Account</h2>
      <Form>
        <Form.Group className="mb-3" controlId="formCustomerId">
          <Form.Label>Customer ID</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter Customer ID"
            value={customerId}
            onChange={(e) => setCustomerId(e.target.value)}
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formName">
          <Form.Label>Name</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formEmail">
          <Form.Label>Email</Form.Label>
          <Form.Control
            type="email"
            placeholder="Enter Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formPhone">
          <Form.Label>Phone Number</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter Phone Number"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formUsername">
          <Form.Label>Username</Form.Label>
          <Form.Control
            type="text"
            placeholder="Enter Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formPassword">
          <Form.Label>Password</Form.Label>
          <Form.Control
            type="password"
            placeholder="Enter Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </Form.Group>

        <div className="button-group">
          <Button variant="primary" onClick={handleUpdate} className="me-2">
            Update Account
          </Button>
          <Button variant="danger" onClick={handleDelete}>
            Delete Account
          </Button>
        </div>
      </Form>

      {message && <Alert variant="success" className="mt-3">{message}</Alert>}
      {error && <Alert variant="danger" className="mt-3">{error}</Alert>}
    </div>
  );
}

export default ModifyAccounts;