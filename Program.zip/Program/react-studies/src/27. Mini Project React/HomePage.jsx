import React from 'react';
import CustomerCard from './CustomerCard';
import ProductCard from './ProductCard';
import OrderCard from './OrderCard';
import NavigationBar from './NavigationBar';
import Footer from './Footer';

{/* Images */}
import image1 from './Images/img1.png';

function Homepage() {
  return (
    <>
      <NavigationBar />
      <img className='img-one-container' src={image1} alt="image-cover"/>
      <div>
        <CustomerCard />
        <ProductCard />
        <OrderCard />
      </div>
      <Footer />
    </>
  );
}

export default Homepage;