import React, { useState } from 'react';
import { Button, Form, Alert, ListGroup } from 'react-bootstrap';
import axios from 'axios';

function SearchProducts() {
  const [productId, setProductId] = useState('');
  const [productData, setProductData] = useState(null);
  const [allProducts, setAllProducts] = useState([]);
  const [error, setError] = useState('');

  const fetchProductById = async () => {
    try {
      const response = await axios.get(`/productcatalog/${productId}`);
      setProductData(response.data);
      setError('');
    } catch (err) {
      setError('Product not found or an error occurred.');
      setProductData(null);
    }
  };

  const fetchAllProducts = async () => {
    try {
      const response = await axios.get('/productcatalog/all');
      setAllProducts(response.data);
      setError('');
    } catch (err) {
      setError('Error fetching products.');
      setAllProducts([]);
    }
  };

  return (
    <div>
      <h3>Search Products</h3>
      <Form>
        <Form.Group className="mb-3">
          <Form.Label>Search by Product ID</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Enter product ID" 
            value={productId} 
            onChange={(e) => setProductId(e.target.value)} 
          />
        </Form.Group>
        <Button variant="primary" onClick={fetchProductById}>Search</Button>
        {' '}
        <Button variant="secondary" onClick={fetchAllProducts}>View All Products</Button>
      </Form>

      {error && <Alert variant="danger" className="mt-3">{error}</Alert>}

      {productData && (
        <div className="mt-3">
          <h4>Product Details</h4>
          <ListGroup>
            <ListGroup.Item><strong>ID:</strong> {productData.product_id}</ListGroup.Item>
            <ListGroup.Item><strong>Name:</strong> {productData.product_name}</ListGroup.Item>
            <ListGroup.Item><strong>Price:</strong> ${productData.price}</ListGroup.Item>
            <ListGroup.Item><strong>Stock Level:</strong> {productData.stock_level}</ListGroup.Item>
          </ListGroup>
        </div>
      )}

      {allProducts.length > 0 && (
        <div className="mt-3">
          <h4>All Products</h4>
          <ListGroup>
            {allProducts.map(product => (
              <ListGroup.Item key={product.product_id}>
                {product.product_name} (${product.price}) - Stock: {product.stock_level}
              </ListGroup.Item>
            ))}
          </ListGroup>
        </div>
      )}
    </div>
  );
}

export default SearchProducts;