import React, { useState } from 'react';
import { Button, Form, Alert, ListGroup } from 'react-bootstrap';
import axios from 'axios';

function SearchOrders() {
  const [orderId, setOrderId] = useState('');
  const [orderData, setOrderData] = useState(null);
  const [allOrders, setAllOrders] = useState([]);
  const [error, setError] = useState('');

  const fetchOrderById = async () => {
    try {
      const response = await axios.get(`/ordermanagement/${orderId}`);
      setOrderData(response.data);
      setError('');
    } catch (err) {
      setError('Order not found or an error occurred.');
      setOrderData(null);
    }
  };

  const fetchAllOrders = async () => {
    try {
      const response = await axios.get('/ordermanagement');
      setAllOrders(response.data);
      setError('');
    } catch (err) {
      setError('Error fetching orders.');
      setAllOrders([]);
    }
  };

  return (
    <div>
      <h3>Search Orders</h3>
      <Form>
        <Form.Group className="mb-3">
          <Form.Label>Search by Order ID</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Enter order ID" 
            value={orderId} 
            onChange={(e) => setOrderId(e.target.value)} 
          />
        </Form.Group>
        <Button variant="primary" onClick={fetchOrderById}>Search</Button>
        {' '}
        <Button variant="secondary" onClick={fetchAllOrders}>View All Orders</Button>
      </Form>

      {error && <Alert variant="danger" className="mt-3">{error}</Alert>}

      {orderData && (
        <div className="mt-3">
          <h4>Order Details</h4>
          <ListGroup>
            <ListGroup.Item><strong>ID:</strong> {orderData.order_id}</ListGroup.Item>
            <ListGroup.Item><strong>Date:</strong> {orderData.place_order_date}</ListGroup.Item>
            <ListGroup.Item><strong>Status:</strong> {orderData.manage_order_history}</ListGroup.Item>
          </ListGroup>
        </div>
      )}

      {allOrders.length > 0 && (
        <div className="mt-3">
          <h4>All Orders</h4>
          <ListGroup>
            {allOrders.map(order => (
              <ListGroup.Item key={order.order_id}>
                ID: {order.order_id}, Status: {order.manage_order_history}, Total: ${order.cal_total_price}
              </ListGroup.Item>
            ))}
          </ListGroup>
        </div>
      )}
    </div>
  );
}

export default SearchOrders;