import React, { useState } from 'react';
import { Button, Form, Alert } from 'react-bootstrap';
import axios from 'axios';

function FormOrder() {
  const [placeOrderDate, setPlaceOrderDate] = useState('');
  const [retrieveOrder, setRetrieveOrder] = useState('');
  const [trackOrder, setTrackOrder] = useState('');
  const [manageOrderHistory, setManageOrderHistory] = useState('');
  const [cancelOrder, setCancelOrder] = useState(false);
  const [calTotalPrice, setCalTotalPrice] = useState('');
  const [customerId, setCustomerId] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/ordermanagement', {
        place_order_date: placeOrderDate,
        retrieve_order: parseInt(retrieveOrder),
        track_order: trackOrder,
        manage_order_history: manageOrderHistory,
        cancel_order: cancelOrder,
        cal_total_price: parseFloat(calTotalPrice),
        customer_id: parseInt(customerId),
      });
      setMessage(response.data.message);
      setError('');
    } catch (err) {
      setError('Error creating order. Please check your inputs.');
      setMessage('');
    }
  };

  return (
    <div>
      <h3>Create Order</h3>
      <Form onSubmit={handleSubmit}>
        <Form.Group className="mb-3">
          <Form.Label>Order Date</Form.Label>
          <Form.Control 
            type="date" 
            value={placeOrderDate} 
            onChange={(e) => setPlaceOrderDate(e.target.value)} 
            required 
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Retrieve Order</Form.Label>
          <Form.Control 
            type="number" 
            placeholder="Enter retrieval time (e.g., 48 hours)" 
            value={retrieveOrder} 
            onChange={(e) => setRetrieveOrder(e.target.value)} 
            required 
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Track Order</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Enter tracking number" 
            value={trackOrder} 
            onChange={(e) => setTrackOrder(e.target.value)} 
            required 
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Order History</Form.Label>
          <Form.Control 
            type="text" 
            placeholder="Enter order history details" 
            value={manageOrderHistory} 
            onChange={(e) => setManageOrderHistory(e.target.value)} 
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Check 
            type="checkbox" 
            label="Cancel Order" 
            checked={cancelOrder} 
            onChange={(e) => setCancelOrder(e.target.checked)} 
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Total Price</Form.Label>
          <Form.Control 
            type="number" 
            placeholder="Enter total price" 
            value={calTotalPrice} 
            onChange={(e) => setCalTotalPrice(e.target.value)} 
            required 
          />
        </Form.Group>
        <Form.Group className="mb-3">
          <Form.Label>Customer ID</Form.Label>
          <Form.Control 
            type="number" 
            placeholder="Enter customer ID" 
            value={customerId} 
            onChange={(e) => setCustomerId(e.target.value)} 
            required 
          />
        </Form.Group>
        <Button variant="primary" type="submit">Create Order</Button>
      </Form>
      {message && <Alert variant="success" className="mt-3">{message}</Alert>}
      {error && <Alert variant="danger" className="mt-3">{error}</Alert>}
    </div>
  );
}

export default FormOrder;