import React from 'react'

function Footer() {
  return (
    <div>
      <footer className="site-footer">
        &copy; {new Date().getFullYear()} Hello Albuquerque! Inc. All rights reserved.
      </footer>
    </div>
  )
}

export default Footer