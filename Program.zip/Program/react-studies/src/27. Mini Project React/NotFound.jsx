import React from 'react';
import { Container, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

function NotFound() {
  const navigate = useNavigate();

  return (
    <div className="not-found-page">
      <Container
        fluid
        className="text-center d-flex flex-column justify-content-center align-items-center"
        style={{
          height: '100vh',
          background: 'linear-gradient(to right, #f2709c, #ff9472)',
          color: '#ffffff',
          padding: '20px',
          position: 'relative',
        }}
      >
        <Button
          variant="light"
          style={{
            position: 'absolute',
            top: '20px',
            left: '20px',
            fontSize: '1rem',
            fontWeight: '600',
            padding: '5px 15px',
            borderRadius: '25px',
          }}
          onClick={() => navigate('/home')}
        >
          Go to Home
        </Button>

        {/* 404 Message */}
        <h1 style={{ fontSize: '4rem', fontWeight: '700', marginBottom: '1rem' }}>
          404 Error
        </h1>
        <p style={{ fontSize: '1.5rem', fontWeight: '300', marginBottom: '2rem' }}>
          Oops! Looks like you’ve wandered into the abyss.
        </p>
        <p style={{ fontSize: '1.2rem', fontStyle: 'italic', marginBottom: '2rem' }}>
          (Sadly, there’s no treasure here… only disappointment.)
        </p>
        <Button
          variant="light"
          size="lg"
          style={{
            fontSize: '1.2rem',
            fontWeight: '600',
            padding: '10px 30px',
            borderRadius: '25px',
            boxShadow: '0px 8px 15px rgba(0, 0, 0, 0.1)',
          }}
          onClick={() => navigate('/')}
        >
          Return to Safety
        </Button>
      </Container>
    </div>
  );
}

export default NotFound;