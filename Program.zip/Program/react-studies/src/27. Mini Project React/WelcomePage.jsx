import React from 'react';
import { Container, Button } from 'react-bootstrap';

function WelcomePage() {
  return (
    <div className="welcome-page">
      <Container
        fluid
        className="text-center d-flex flex-column justify-content-center align-items-center"
        style={{
          height: '100vh',
          background: 'linear-gradient(to right, #4facfe, #00f2fe)',
          color: '#ffffff',
        }}
      >
        <h1 style={{ fontSize: '4rem', fontWeight: '700', marginBottom: '1rem' }}>
          Welcome to Your Management System
        </h1>
        <p style={{ fontSize: '1.5rem', fontWeight: '300', marginBottom: '2rem' }}>
          Manage your customers, products, and orders with ease!
        </p>
        <Button
          href="/home"
          variant="light"
          size="lg"
          style={{
            fontSize: '1.2rem',
            fontWeight: '600',
            padding: '10px 30px',
            borderRadius: '25px',
            boxShadow: '0px 8px 15px rgba(0, 0, 0, 0.1)',
          }}
        >
          Go to Home Page
        </Button>
      </Container>
    </div>
  );
}

export default WelcomePage;