{/* FINAL PROJECT FOR CLASS 1 :)*/}
{/* */}
import { Routes, Route } from 'react-router-dom';
import React from 'react';
import WelcomePage from './27. Mini Project React/WelcomePage';
import HomePage from './27. Mini Project React/HomePage';
import ContactUs from './27. Mini Project React/ContactUs';
import NotFound from './27. Mini Project React/NotFound';
import 'bootstrap/dist/css/bootstrap.min.css';

const App = () => {
  return (
    <div>
      <Routes>
        <Route path="/" element={<WelcomePage />} />
        <Route path="/home" element={<HomePage />} />
        <Route path="/contact" element={<ContactUs />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </div>
  );
};

export default App;